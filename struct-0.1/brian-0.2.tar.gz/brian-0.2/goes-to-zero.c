#include <stdio.h>

int main() 
{
  int x; x = 10;
  while (x --> 0) { /* x tende a zero? */
    printf("%d\n", x);
  }
}
