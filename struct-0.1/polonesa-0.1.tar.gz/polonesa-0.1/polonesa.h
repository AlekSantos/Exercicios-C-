#ifndef POLONESA_H
#define POLONESA_H

#define NUMBER '0'

void push(int);
int pop(void);
int getop(char []);
int getch(void);
void ungetch(int);

#endif
