#include <stdio.h>

int main() {
  int a = 1091908786;
  printf("%x\n", a);

  unsigned long x = 0UL; /* o número que você obteve */
  printf("%lx\n", x);
}
