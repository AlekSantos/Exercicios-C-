
int quantos(void) { 
  return 12; 
}
