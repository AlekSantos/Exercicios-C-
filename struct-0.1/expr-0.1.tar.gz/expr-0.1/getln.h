#ifndef GETLN_H
#define GETLN_H

int getln(char[], int);

#endif
